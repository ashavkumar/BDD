package com.cg.payroll.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class CalculateNetSalaryPage {
	@FindBy(how=How.ID,id="associateId")
	private WebElement associateId;	
	@FindBy(how=How.NAME,name="submit")
	private WebElement button;

	@FindBy(how=How.XPATH,xpath="")
	private WebElement actualErrorMessage;
	public CalculateNetSalaryPage() {
		super();
	}
	public String getAssociateId() {
		return associateId.getAttribute("value");
	}
	public void setAssociateId(String associateId) {
		this.associateId.sendKeys(associateId);
	}

	public String getActualErrorMessage() {
		return actualErrorMessage.getText();
	}
	public void clickSignIn() {
		button.submit();
	}
}
