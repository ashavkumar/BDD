package com.cg.payroll.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class ViewAllAssociateDetailsPage {

	@FindBy(how=How.NAME,name="submit")
	private WebElement button;

	public ViewAllAssociateDetailsPage() {
		super();
	}

	public void clickSignIn() {
		button.submit();
	}
}
