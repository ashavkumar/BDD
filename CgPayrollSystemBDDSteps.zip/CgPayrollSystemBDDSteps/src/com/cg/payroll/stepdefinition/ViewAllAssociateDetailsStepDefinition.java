package com.cg.payroll.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAllAssociateDetailsStepDefinition {
	/*Feature: View All Associate Details Feature
	  Using this feature Admin will be able to View All Associate Details

	  Scenario: Admin wants to 'View All Associate Details'          # D:/java/BDD/CgPayrollSystemBDDSteps/features/viewAllAssociateDetailsFeature.feature:4
	    Given Admin is on the HomePage of 'Capgemini Payroll System'
	    When Admin clicks on 'View All Associate Details' button
	    Then Admin is directed to 'viewAllAssociateDetailsPage'

	1 Scenarios (1 undefined)
	3 Steps (3 undefined)
	0m0.000s


	You can implement missing steps with the snippets below:
*/
	@Given("^Admin is on the HomePage of 'Capgemini Payroll System'$")
	public void admin_is_on_the_HomePage_of_Capgemini_Payroll_System() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Admin clicks on 'View All Associate Details' button$")
	public void admin_clicks_on_View_All_Associate_Details_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Admin is directed to 'viewAllAssociateDetailsPage'$")
	public void admin_is_directed_to_viewAllAssociateDetailsPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
