package com.cg.payroll.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculateNetSalaryStepDefinition {
	/*Feature: Calculate Net Salary Feature
	  Using this feature Associate will be able to Calculate Net Salary

	  Scenario: Associate wants to calculate 'Net Salary'                # D:/java/159944_Sushant_Dey/CgPayrollSystem/features/calculateNetSalaryFeature.feature:4
	    Given Associate is on the HomePage of 'Capgemini Payroll System'
	    When Associate clicks on 'Calculate Net Salary' button
	    Then Associate is directed to 'calculateNetSalaryPage'

	  Scenario: Associate wants to 'Calculate Net Salary' by entering 'associateId' # D:/java/159944_Sushant_Dey/CgPayrollSystem/features/calculateNetSalaryFeature.feature:9
	    Given Associate is on 'calculateNetSalaryPage'
	    When Associate enters valid 'associateId'
	    Then Associate is directed to 'displayNetSalaryPage'
	    When Associate enters invalid 'associateId'
	    Then Display 'Invalid associateId' Error message

	2 Scenarios (2 undefined)
	8 Steps (8 undefined)
	0m0.000s


	You can implement missing steps with the snippets below:
*/
	@Given("^Associate is on the HomePage of 'Capgemini Payroll System'$")
	public void associate_is_on_the_HomePage_of_Capgemini_Payroll_System() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Associate clicks on 'Calculate Net Salary' button$")
	public void associate_clicks_on_Calculate_Net_Salary_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Associate is directed to 'calculateNetSalaryPage'$")
	public void associate_is_directed_to_calculateNetSalaryPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^Associate is on 'calculateNetSalaryPage'$")
	public void associate_is_on_calculateNetSalaryPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Associate enters valid 'associateId'$")
	public void associate_enters_valid_associateId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Associate is directed to 'displayNetSalaryPage'$")
	public void associate_is_directed_to_displayNetSalaryPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Associate enters invalid 'associateId'$")
	public void associate_enters_invalid_associateId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Display 'Invalid associateId' Error message$")
	public void display_Invalid_associateId_Error_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
