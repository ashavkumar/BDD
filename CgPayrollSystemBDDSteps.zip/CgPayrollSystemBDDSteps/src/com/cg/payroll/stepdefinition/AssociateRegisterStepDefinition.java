package com.cg.payroll.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AssociateRegisterStepDefinition {
	private WebDriver driver;
	@Given("^Associate is on the Capgemini Payroll System 'indexPage'$")
	public void associate_is_on_the_Capgemini_Payroll_System_indexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4443");
	}

	@When("^Associate clicks on 'Register' button$")
	public void associate_clicks_on_Register_button() throws Throwable {
		By by=By.name("/");
		WebElement btnRegister=driver.findElement(by);
		btnRegister.submit();
	}

	@Then("^Associate is directed to 'registerPage'$")
	public void associate_is_directed_to_registerPage() throws Throwable {

	}

	@Given("^Associate is on 'registerPage'$")
	public void associate_is_on_registerPage() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^Associate enters valid Registration details$")
	public void associate_enters_valid_Registration_details() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^Associate is directed to 'registrationSuccessPage'$")
	public void associate_is_directed_to_registrationSuccessPage() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^Associate enters invalid Registration details$")
	public void associate_enters_invalid_Registration_details() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^Display 'Registration Error message'$")
	public void display_Registration_Error_message() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}


}
