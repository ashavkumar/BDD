package com.cg.payroll.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAssociateDetailsStepDefinition {
	/*Feature: View Associate Details Feature
	  Using this feature Associate will be able to View Associate Details

	  Scenario: Associate wants to 'View Associate Details'              # D:/java/BDD/CgPayrollSystemBDDSteps/features/viewAssociateDetailsFeature.feature:4
	    Given Associate is on the HomePage of 'Capgemini Payroll System' # CalculateNetSalaryStepDefinition.associate_is_on_the_HomePage_of_Capgemini_Payroll_System()
	      cucumber.api.PendingException: TODO: implement me
	      	at com.cg.payroll.stepdefinition.CalculateNetSalaryStepDefinition.associate_is_on_the_HomePage_of_Capgemini_Payroll_System(CalculateNetSalaryStepDefinition.java:34)
	      	at ?.Given Associate is on the HomePage of 'Capgemini Payroll System'(D:/java/BDD/CgPayrollSystemBDDSteps/features/viewAssociateDetailsFeature.feature:5)

	    When Associate clicks on 'View Associate Details' button
	    Then Associate is directed to 'viewAssociateDetailsPage'

	  Scenario: Associate wants to 'View Associate Details' by entering 'associateId' # D:/java/BDD/CgPayrollSystemBDDSteps/features/viewAssociateDetailsFeature.feature:9
	    Given Associate is on 'viewAssociateDetailsPage'
	    When Associate enters valid 'associateId'                                     # CalculateNetSalaryStepDefinition.associate_enters_valid_associateId()
	    Then Associate is directed to 'displayAssociateDetailsPage'
	    When Associate enters invalid 'associateId'                                   # CalculateNetSalaryStepDefinition.associate_enters_invalid_associateId()
	    Then Display 'Invalid associateId' Error message                              # CalculateNetSalaryStepDefinition.display_Invalid_associateId_Error_message()

	2 Scenarios (2 undefined)
	8 Steps (3 skipped, 1 pending, 4 undefined)
	0m0.199s

	cucumber.api.PendingException: TODO: implement me
		at com.cg.payroll.stepdefinition.CalculateNetSalaryStepDefinition.associate_is_on_the_HomePage_of_Capgemini_Payroll_System(CalculateNetSalaryStepDefinition.java:34)
		at ?.Given Associate is on the HomePage of 'Capgemini Payroll System'(D:/java/BDD/CgPayrollSystemBDDSteps/features/viewAssociateDetailsFeature.feature:5)


	You can implement missing steps with the snippets below:
*/
	@When("^Associate clicks on 'View Associate Details' button$")
	public void associate_clicks_on_View_Associate_Details_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Associate is directed to 'viewAssociateDetailsPage'$")
	public void associate_is_directed_to_viewAssociateDetailsPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^Associate is on 'viewAssociateDetailsPage'$")
	public void associate_is_on_viewAssociateDetailsPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Associate is directed to 'displayAssociateDetailsPage'$")
	public void associate_is_directed_to_displayAssociateDetailsPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
